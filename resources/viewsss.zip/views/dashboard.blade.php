@extends('admin.layout')

@section('content')
<div class="content-wrapper">
    <div class="content-body">
        <h2>Welcome To Dashboard</h2>
    </div>
</div>
@endsection