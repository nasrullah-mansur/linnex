<footer class="footer footer-static footer-light navbar-border">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
        <span class="float-md-left d-block d-md-inline-block">
            
        </span>
        <span class="float-md-right d-block d-md-inline-block d-none d-lg-block">Developer :: Nasrullah Mansur</span>
    </p>
</footer>
