<!-- Scripts -->
<script src="{{ asset('front/assets/js/jquery.2.2.4.min.js') }}"></script>
<script src="{{ asset('front/assets/js/slick.min.js') }}"></script>
<script src="{{ asset('front/assets/js/custom.js') }}"></script>

{!! $custom ? $custom->js : '' !!}